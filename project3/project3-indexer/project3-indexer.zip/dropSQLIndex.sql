DROP INDEX Coordinates_Index ON Location;
DROP TABLE IF EXISTS Location;